public class Amfibia extends PojazdPlywajacy {
	public Amfibia(String _name) {
		super(_name);
	}
	protected String getKind() {
		return "amfibia";
	}
}