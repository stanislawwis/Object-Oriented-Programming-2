public class Starter {
	public static void start(Pojazd vehicle) {
		vehicle.start();
	}
	public static void stop(Pojazd vehicle) { 
		vehicle.stop();
	}
}