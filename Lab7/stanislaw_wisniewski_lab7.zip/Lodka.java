public class Lodka extends PojazdPlywajacy {
	public Lodka(String _name) {
		super(_name);
	}
	protected String getKind() { 
		return "lodka";
	}
}